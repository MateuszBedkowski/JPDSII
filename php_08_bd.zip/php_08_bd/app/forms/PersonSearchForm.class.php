<?php

namespace app\forms;

class PersonSearchForm {
	public $surname;
} 