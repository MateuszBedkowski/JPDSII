<?php

namespace app\forms;

class CalculateForm{
    public $amount;
    public $percentage;
    public $months;
    public $monthlyPayment;
}