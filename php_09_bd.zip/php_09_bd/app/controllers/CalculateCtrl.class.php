<?php

namespace app\controllers;

use core\App;
use core\Utils;
use core\ParamUtils;
use core\Validator;
use app\forms\CalculateForm;

class CalculateCtrl {
    
    private $form;

    public function __construct() {
        $this->form = new CalculateForm();
    }

    public function action_calculate()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->form->amount = ParamUtils::getFromPost('amount');
            $this->form->percentage = ParamUtils::getFromPost('percentage');
            $this->form->months = ParamUtils::getFromPost('months');

            if (empty(trim($this->form->amount))) {
                Utils::addErrorMessage('Wprowadź kwotę');
            }
            if (empty(trim($this->form->percentage))) {
                Utils::addErrorMessage('Wprowadź oprocentowanie');
            }
            if (empty(trim($this->form->months))) {
                Utils::addErrorMessage('Wprowadź okres');
            }

            if (!App::getMessages()->isError()) {
                $validator = new Validator();
                $validator->validateFloat($this->form->amount, 'amount', true);
                $validator->validateFloat($this->form->percentage, 'percentage', true);
                $validator->validateInt($this->form->months, 'months', true);

                if (App::getMessages()->isEmpty()) {
                    $monthlyPayment = $this->calculateMonthlyPayment(
                        $this->form->amount,
                        $this->form->percentage,
                        $this->form->months
                    );
                    $formattedMonthlyPayment = number_format($monthlyPayment, 2, ',', ' ');
                    App::getSmarty()->assign('monthlyPayment', $formattedMonthlyPayment);
                } else {
                    $errors = App::getMessages()->getErrors();
                    foreach ($errors as $error) {
                        Utils::addErrorMessage($error);
                    }
                }
            }
        }

        $this->generateView();
    }

    private function calculateMonthlyPayment($amount, $percentage, $months)
    {
        return ($amount + $amount * ($percentage / 100)) / $months;
    }

    public function generateView()
    {
        App::getSmarty()->assign('form', $this->form);
        App::getSmarty()->display('CalculateView.tpl');
    }

    // ...
}
