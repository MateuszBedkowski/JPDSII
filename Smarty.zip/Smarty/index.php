<?php
require_once 'config.php';

// Ustawienia szablonu Smarty
require_once 'smarty-master/libs/Smarty.class.php';
$smarty = new Smarty();
$smarty->setTemplateDir('templates/');
$smarty->setCompileDir('templates_c/');
$smarty->setCacheDir('cache/');
$smarty->setConfigDir('configs/');

// Początkowe wartości pól formularza
$form = [
    'kwota' => '',
    'oprocentowanie' => '',
    'okres' => '',
    'rata' => ''
];

// Komunikaty walidacyjne
$messages = [];

// Sprawdzenie czy formularz został przesłany
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Pobranie danych z formularza
    $form['kwota'] = $_POST['kwota'];
    $form['oprocentowanie'] = $_POST['oprocentowanie'];
    $form['okres'] = $_POST['okres'];

    // Sprawdzenie poprawności danych
    if (!is_numeric($form['kwota'])) {
        $messages[] = 'Kwota musi być liczbą!';
    }
    if (!is_numeric($form['oprocentowanie'])) {
        $messages[] = 'Oprocentowanie musi być liczbą!';
    }
    if (!is_numeric($form['okres'])) {
        $messages[] = 'Okres musi być liczbą!';
    }

    // Obliczenie raty
    if (empty($messages)) {
        $kwota = (int) $form['kwota'];
        $oprocentowanie = (float) $form['oprocentowanie'];
        $okres = (int) $form['okres'];

        $rata = ($kwota * ($oprocentowanie / 1200)) / (1 - pow((1 + ($oprocentowanie / 1200)), (-$okres)));

        $form['rata'] = round($rata, 2) . ' zł';
    }
}

// Przekazanie zmiennych do szablonu Smarty
$smarty->assign('_app_url', _APP_URL);
$smarty->assign('form', $form);
$smarty->assign('messages', $messages);
$smarty->display('calc_view.tpl');
