<?php
// pobieramy dane z formularza
$amount = isset($_POST['amount']) ? intval($_POST['amount']) : 0;
$interest = isset($_POST['interest']) ? intval($_POST['interest']) : 0;
$period = isset($_POST['period']) ? intval($_POST['period']) : 0;

// sprawdzamy, czy dane są poprawne
if ($amount <= 0 || $interest <= 0 || $period <= 0) {
    echo "Wprowadzone dane są nieprawidłowe. Proszę spróbować ponownie.";
    exit;
}

// przeprowadzamy obliczenia
$interest_percent = $interest / 100;
$monthly_interest = $interest_percent / 12;
$months = $period * 12;
$monthly_payment = ($amount * $monthly_interest) / (1 - pow(1 + $monthly_interest, -$months));

// wyświetlamy wynik
echo "Miesięczna rata kredytu wynosi: " . round($monthly_payment, 2) . " zł.";
?>
