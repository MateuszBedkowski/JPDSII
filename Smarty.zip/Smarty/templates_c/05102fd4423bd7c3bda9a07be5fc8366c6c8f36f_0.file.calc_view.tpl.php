<?php
/* Smarty version 4.3.1, created on 2023-05-07 20:27:51
  from 'C:\xampp\htdocs\proba\calc_view.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.1',
  'unifunc' => 'content_6457eda7d49d96_94948894',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '05102fd4423bd7c3bda9a07be5fc8366c6c8f36f' => 
    array (
      0 => 'C:\\xampp\\htdocs\\proba\\calc_view.tpl',
      1 => 1683484071,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6457eda7d49d96_94948894 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1022983226457eda7d3fce3_02903961', "content");
?>
 
<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "templates_c/Progressus/contact.html");
}
/* {block "content"} */
class Block_1022983226457eda7d3fce3_02903961 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_1022983226457eda7d3fce3_02903961',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


    <h2 class="content-head is-center">Kalkulator kredytowy</h2>

    <div class="pure-g">
        <div class="l-box-lrg pure-u-1 pure-u-med-2-5">
            <form class="pure-form pure-form-stacked" action="<?php echo $_smarty_tpl->tpl_vars['app_url']->value;?>
/calc.php" method="post">
                <fieldset>

                    <label for="kwota">Kwota kredytu</label>
                    <input id="kwota" type="text" placeholder="wartość" name="kwota" value="<?php echo $_smarty_tpl->tpl_vars['form']->value['kwota'];?>
" required>

                    <label for="oprocentowanie">Oprocentowanie</label>
                    <input id="oprocentowanie" type="text" placeholder="wartość w %" name="oprocentowanie" value="<?php echo $_smarty_tpl->tpl_vars['form']->value['oprocentowanie'];?>
" required>

                    <label for="okres">Okres spłaty (w miesiącach)</label>
                    <input id="okres" type="text" placeholder="wartość w miesiącach" name="okres" value="<?php echo $_smarty_tpl->tpl_vars['form']->value['okres'];?>
" required>

                    <button type="submit" class="pure-button">Oblicz</button>
                </fieldset>
            </form>
        </div>

        <div class="l-box-lrg pure-u-1 pure-u-med-3-5">

            <?php if ((isset($_smarty_tpl->tpl_vars['result']->value))) {?>
                <h4>Podsumowanie</h4>
                <p class="res">
                    Miesięczna rata: <?php echo $_smarty_tpl->tpl_vars['result']->value['rata'];?>
 zł<br>
                    Kwota do spłaty: <?php echo $_smarty_tpl->tpl_vars['result']->value['do_splaty'];?>
 zł<br>
                    Suma odsetek: <?php echo $_smarty_tpl->tpl_vars['result']->value['suma_odsetek'];?>
 zł
                </p>
            <?php }?>

            <div class="contact-wrapper pure-g">
                <div class="pure-u-1 pure-u-md-1-2">
                    <form class="pure-form pure-form-stacked" method="post" action="mailer.php">
                        <fieldset>
                            <label for="name">Twoje imię:</label>
                            <input id="name" type="text" placeholder="Jan Kowalski" name="name" required>

                            <label for="email">Twój email:</label>
                            <input id="email" type="email" placeholder="jankowalski@domena.pl" name="email" required>

                            <label for="message">Wiadomość:</label>
                            <textarea id="message" name="message" required></textarea>

                            <button type="submit" class="pure-button">Wyślij</button>
                        </fieldset>
                    </form>
                </div>

                <div class="pure-u-1 pure-u-md-1-2">


                    <h3>Email</h3>
                    <p>
                        hello@example.com
                    </p>

                    <h3>Telefon</h3>
                    <p>
                        +31 123 456 789
                    </p>
                </div>
            </div>

        </div>
    </div>

<?php
}
}
/* {/block "content"} */
}
