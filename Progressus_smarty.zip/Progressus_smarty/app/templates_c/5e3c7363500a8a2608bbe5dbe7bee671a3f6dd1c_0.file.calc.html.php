<?php
/* Smarty version 4.3.1, created on 2023-04-17 10:39:25
  from 'C:\xampp\htdocs\php_02_ochrona_dostepu\app\security\Progressus\calc.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.1',
  'unifunc' => 'content_643d05bd0e18f7_07393004',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '5e3c7363500a8a2608bbe5dbe7bee671a3f6dd1c' => 
    array (
      0 => 'C:\\xampp\\htdocs\\php_02_ochrona_dostepu\\app\\security\\Progressus\\calc.html',
      1 => 1681720763,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_643d05bd0e18f7_07393004 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, false);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_2086475310643d05bd0de336_21464437', 'footer');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1190865296643d05bd0df823_12173995', 'content');
}
/* {block 'footer'} */
class Block_2086475310643d05bd0de336_21464437 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'footer' => 
  array (
    0 => 'Block_2086475310643d05bd0de336_21464437',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
przykładowa tresć stopki wpisana do szablonu głównego z szablonu kalkulatora<?php
}
}
/* {/block 'footer'} */
/* {block 'content'} */
class Block_1190865296643d05bd0df823_12173995 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_1190865296643d05bd0df823_12173995',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<head>
	<meta charset="utf-8">
	<meta name="viewport"    content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	<meta name="author"      content="Sergey Pozhilov (GetTemplate.com)">
	
	<title>Kalkulator kredytowy</title>

	<link rel="shortcut icon" href="assets/images/gt_favicon.png">
	
	<link rel="stylesheet" media="screen" href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,700">
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/css/font-awesome.min.css">

	<!-- Custom styles for our template -->
	<link rel="stylesheet" href="assets/css/bootstrap-theme.css" media="screen" >
	<link rel="stylesheet" href="assets/css/main.css">

	<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!--[if lt IE 9]>
	<?php echo '<script'; ?>
 src="assets/js/html5shiv.js"><?php echo '</script'; ?>
>
	<?php echo '<script'; ?>
 src="assets/js/respond.min.js"><?php echo '</script'; ?>
>
	<![endif]-->
</head>

<body>
	<!-- Fixed navbar -->
	<div class="navbar navbar-inverse navbar-fixed-top headroom" >
		<div class="container">
			<div class="navbar-header">
				<!-- Button for smallest screens -->
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"><span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
				<a class="navbar-brand" href=""><img src="assets/images/logo.png" alt="Progressus HTML5 template"></a>
			</div>
			<div class="navbar-collapse collapse">
				<ul class="nav navbar-nav pull-right">
					<li class="active"><a href="../../inna_chroniona.php">Inna chroniona</a></li>
					<li><a class="btn" href="../logout.php" class="pure-button pure-button-active">Wyloguj</a></li>
				</ul>
			</div><!--/.nav-collapse -->
		</div>
	</div> 
	<!-- /.navbar -->

	<header id="head" class="secondary"></header>

	<!-- container -->
	<div class="container">
		<div class="row">

		<form class="pure-form pure-form-stacked" action="<?php echo $_smarty_tpl->tpl_vars['app_url']->value;?>
../../../../calc.php" method="post">
			
			<!-- Article main content -->
			<article class="col-sm-9 maincontent">
				<header class="page-header">
					<h1 class="page-title">Kalkulator kredytowy</h1>
				</header>
				
				<p>
					Wprowadź kwotę pożyczki, oprocentowanie oraz liczbę rat.
				</p>
				<br>
					<form>
						<div class="row">
							<div class="col-sm-4">
								<label for="kwota"></label> 
								<input id="kwota" type="text" placeholder="Kwota pożyczki">
							</div>
							<div class="col-sm-4">
								<label for="oprocentowanie"></label>
								<input id="oprocentowanie" type="text" placeholder="Oprocentowanie">
							</div>
							<div class="col-sm-4">
								<label for="miesiace"></label>
								<input id="miesiace" type="text" placeholder="Liczba rat">
							</div>
						</div>
						<br>
						<br>
						<!-- <div class="row">
							<div clas="col-sm-6 text-center">
								<h4>Wynik: </h4>
								<p class="res"><?php echo '<?php'; ?>
 echo $result <?php echo '?>'; ?>
</p>
						</div> -->
						<br>
						<br>
						<div class="row">
							<div class="col-sm-11 text-right">
								<input class="btn btn-action" type="submit" value="Oblicz ratę">
							</div>
						</div>
					</form>

			</article>
			<!-- /Article -->
			
			<!-- Sidebar -->
			<aside class="col-sm-3 sidebar sidebar-right">

			</aside>
			<!-- /Sidebar -->

		</div>
	</div>	<!-- /container -->



<!-- <?php echo '<?php'; ?>

//wyświeltenie listy błędów, jeśli istnieją
if (isset($messages)) {
	if (count ( $messages ) > 0) {
		echo '<ol style="margin-top: 1em; padding: 1em 1em 1em 2em; border-radius: 0.5em; background-color: #f88; width:25em;">';
		foreach ( $messages as $key => $msg ) {
			echo '<li>'.$msg.'</li>';
		}
		echo '</ol>';
	}
}
<?php echo '?>'; ?>


<?php echo '<?php'; ?>
 if (isset($result)){ <?php echo '?>'; ?>

<div style="margin-top: 1em; padding: 1em; border-radius: 0.5em; background-color: #ff0; width:25em;">
<?php echo '<?php'; ?>
 echo 'Miesięczna rata: '.$result; <?php echo '?>'; ?>

</div>
<?php echo '<?php'; ?>
 } <?php echo '?>'; ?>
 -->


	<footer id="footer">

		<div class="footer1">
			<div class="container">
				<div class="row">
					
					<div class="col-md-3 widget">
						<h3 class="widget-title">Contact</h3>
						<div class="widget-body">
							<p>+48 123 456 789<br>
								<a href="mailto:mbedkowski@o365.us.edu.pl">mbedkowski@o365.us.edu.pl</a><br>
								<br>
								Sosnowiec, ul. Będzińska 39
							</p>	
						</div>
					</div>

					<div class="col-md-3 widget">
						<h3 class="widget-title">Follow me</h3>
						<div class="widget-body">
							<p class="follow-me-icons clearfix">
								<a href="https://github.com/MateuszBedkowski"><i class="fa fa-github fa-2"></i></a>
								<a href="https://www.facebook.com/profile.php?id=100011237889315"><i class="fa fa-facebook fa-2"></i></a>
							</p>	
						</div>
					</div>

					<div class="col-md-6 widget">
						<h3 class="widget-title">Text widget</h3>
						<div class="widget-body">
							<p>Przykładowy tekst, którego zdaniem jest wypełnienie tła. Nie należy się tym teraz przejmować, może później wsadzę jakieś wiersze :)</p>
							<p>Nie należy sugerować się ceną przy wyborze piłki do grania, ponieważ bardzo często zdarza się, że ta najdroższa nie jest wcale najlepsza.</p>
						</div>
					</div>

				</div> <!-- /row of widgets -->
			</div>
		</div>

		<div class="footer2">
			<div class="container">
				<div class="row">
					<div class="col-md-6 widget">
						<div class="widget-body">
							<p class="text-right">
								Copyright &copy; 2023, Mateusz Będkowski. Designed by <a href="http://gettemplate.com/" rel="designer">gettemplate</a> 
							</p>
						</div>
					</div>

				</div> <!-- /row of widgets -->
			</div>
		</div>
	</footer>	
		


	<!-- JavaScript libs are placed at the end of the document so the pages load faster -->
	<?php echo '<script'; ?>
 src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"><?php echo '</script'; ?>
>
	<?php echo '<script'; ?>
 src="http://netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"><?php echo '</script'; ?>
>
	<?php echo '<script'; ?>
 src="assets/js/headroom.min.js"><?php echo '</script'; ?>
>
	<?php echo '<script'; ?>
 src="assets/js/jQuery.headroom.min.js"><?php echo '</script'; ?>
>
	<?php echo '<script'; ?>
 src="assets/js/template.js"><?php echo '</script'; ?>
>
	
	<!-- Google Maps -->
	<?php echo '<script'; ?>
 src="https://maps.googleapis.com/maps/api/js?key=&amp;sensor=false&amp;extension=.js"><?php echo '</script'; ?>
> 
	<?php echo '<script'; ?>
 src="assets/js/google-map.js"><?php echo '</script'; ?>
>
	
	

</body>

<div class="l-box-lrg pure-u-1 pure-u-med-3-5">
<?php
}
}
/* {/block 'content'} */
}
