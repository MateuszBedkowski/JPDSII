<?php
class CalcForm {
	public $x;
	public $y;
	public $op;
} 