<?php

namespace app\forms;

class CalcForm {
	public $kwota;
	public $okres;
	public $oprocentowanie;
} 